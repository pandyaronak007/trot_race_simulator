import VerifyMapping from "../components/verifyMapping";

const Starter = () => {
  return (
    <div>
      <VerifyMapping />
    </div>
  );
};

export default Starter;
