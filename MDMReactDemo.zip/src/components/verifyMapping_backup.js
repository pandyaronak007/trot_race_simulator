import React, { useState, useRef, useEffect } from 'react';
import JsonData from '../services/salesSellOut.json';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Button } from 'primereact/button';
import { Dialog } from 'primereact/dialog';
import { InputText } from 'primereact/inputtext';
import { Dropdown } from 'primereact/dropdown';
import { Col, Row } from "reactstrap";
import { Toast } from 'primereact/toast';
import { ProgressSpinner } from 'primereact/progressspinner';
import errorPic from "../assets/images/users/Error.svg";
import inReviewPic from "../assets/images/users/InReview.svg";
import successPic from "../assets/images/users/Success.svg";
import api from '../services/api';

const VerifyMapping = () => {
    const [products0, setProducts0] = useState([]);
    const [products1, setProducts1] = useState([]);
    const [products2, setProducts2] = useState(null);
    const [dataSource, setDataSource] = useState('');
    const [visibleRight, setVisibleRight] = useState(false);
    const [displayPosition, setDisplayPosition] = useState(false);
    const [position, setPosition] = useState('center');
    const [headerValue, setHeaderValue] = useState(null);
    const toast = useRef(null);
    const [visible, setVisible] = useState(false);
    const [nameVisible, setNameVisible] = useState('Running Data Quality Checks');
    // const [statuses] = useState(['Approved']);


    // updated column for the products
    const [getCategory, setCategory] = useState('');
    const [getManufacturer, setManufacturer] = useState('');
    const [getBrand, setBrand] = useState('');
    const [getSubBrand, setSubbrand] = useState('');
    const [getGroupName, setGroupName] = useState('');
    const [getSubBrandName, setSubBrandName] = useState('');

    useEffect(() => {
        if (visible) {
            setTimeout(() => {
                setNameVisible('Running Data Quality Checks');
                setVisible(false);
            }, 1000);
        }
    }, [visible]);

    const tableStyle = { 'backgroundColor': 'white', 'paddingLeft': '30px', 'paddingRight': '30px', 'paddingBottom': '30px' };
    const buttonStyle = { 'borderRadius': '8px' };
    const borderStyle = { "border": '1px solid' };

    const dialogFuncMap = {
        'visibleRight': setVisibleRight,
        'displayPosition': setDisplayPosition
    }

    const groupedCities = [
        {
            label: 'Sales',
            items: [
                { label: 'Sell In Data (SAP/ERP)', value: '1' },
                { label: 'Sell out (EDW)', value: '2' }
            ]
        },
        {
            label: 'Media',
            items: [
                { label: 'OMD', value: '3' }
            ]
        }
    ];

    const groupedItemTemplate = (option) => {
        return (
            <div className="flex align-items-left">
                <div>{option.label}</div>
            </div>
        );
    };

    const onClick = (name, position, e) => {
        dialogFuncMap[`${name}`](true);
        if (position)
            setPosition(position);
        if (e && e.id) {
            setProducts2([e])
            setHeaderValue(e.id)
        }
    }

    const onHide = (name) => {
        dialogFuncMap[`${name}`](false);
        setProducts2([])
        setHeaderValue(null)
    }

    const callApi = () => {
        api.getData()             
            .then((response) => {
                console.log('response ===>', response)
            })
            .catch((error) => {
                console.log('error ===>', error)
            })
    }

    const callVerifyMapping = () => {
        setVisible(true)
        callApi();
        if (products0?.length > 0) {
            setProducts1(products0)
            setProducts0([])
        }
    }

    const CustomDemo = () => {
        return (
            <div className="card">
                <ProgressSpinner />
                {/* <ProgressSpinner style={{ width: '50px', height: '50px' }} strokeWidth="8" fill="var(--surface-ground)"
                    animationDuration=".5s" InputText="Running Data Quality Checks" /> */}
            </div>
        );
    }

    const callAnotherDialog = (name) => {
        dialogFuncMap[`${name}`](false);
        if (products2?.length > 0) {
            setCategory(products2[0].category || '')
            setManufacturer(products2[0].manufacturer || '')
            setBrand(products2[0].brand || '')
            setSubbrand(products2[0].sub_brand || '')
            setGroupName(products2[0].suggested_group_name || '')
            setSubBrandName(products2[0].suggested_sub_brand_name || '')
        }
        return onClick('visibleRight', 'top-right');
    }

    const updateDataInGrid = (name) => {
        setNameVisible('Manual Suggestion Are Updating')
        setVisible(true)
        dialogFuncMap[`${name}`](false);
        const getAllProducts = products1;

        let _products = getAllProducts.find(val => val.id === products2[0].id);
        _products.category = getCategory || '';
        _products.manufacturer = getManufacturer || '';
        _products.brand = getBrand || '';
        _products.sub_brand = getSubBrand || '';
        _products.suggested_group_name = getGroupName || '';
        _products.suggested_sub_brand_name = getSubBrandName || '';
        _products.status = 'In Review';
        _products.version = 'v0.0.5';
        setProducts1(getAllProducts)
        toast.current.show({ severity: 'success', summary: 'Successful', detail: 'Product Manually Updated', life: 3000 });
        setProducts2(null)
        setHeaderValue(null)
    }

    const updateAutoSuggestion = (name) => {
        setNameVisible('Apply Suggestion Are Updating')
        setVisible(true)
        dialogFuncMap[`${name}`](false);
        const getAllProducts = products1;

        let _products = getAllProducts.find(val => val.id === products2[0].id);
        let getLastNumber = Number(_products.version.slice(-1));
        _products.status = 'In Review';
        _products.version = _products.version.slice(0, -1) + (getLastNumber + 1).toString();
        setProducts1(getAllProducts)
        toast.current.show({ severity: 'success', summary: 'Successful', detail: 'Product Apply Suggestion Updated', life: 3000 });
        setProducts2(null)
        setHeaderValue(null)
    }

    const renderFooter = (name) => {
        return (
            <div className="flex flex-wrap justify-content-center gap-3">
                <Button label="Manual Correction" onClick={() => callAnotherDialog(name)} outlined rounded style={buttonStyle} />
                <Button label="Apply Suggestion" onClick={() => updateAutoSuggestion(name)} autoFocus rounded style={buttonStyle} />
            </div>
        );
    }

    const renderFooter2 = (name) => {
        return (
            <div className="flex flex-wrap justify-content-center">
                <Button label="Submit" style={{ 'padding': '10px', ...buttonStyle }}
                    onClick={() => updateDataInGrid(name)} autoFocus rounded />
            </div>
        );
    }

    const columns0 = [
        { field: 'verified', header: '' },
        { field: 'id', header: 'Id' },
        { field: 'category', header: 'Category', },
        { field: 'manufacturer', header: 'Manufacturer', },
        { field: 'brand', header: 'Brand', },
        { field: 'sub_brand', header: 'Sub Brand', }
    ];

    const columns = [
        { field: 'verified', header: '' },
        { field: 'id', header: 'Id' },
        { field: 'category', header: 'Category', },
        { field: 'manufacturer', header: 'Manufacturer', },
        { field: 'brand', header: 'Brand', },
        { field: 'sub_brand', header: 'Sub Brand', },
        { field: 'version', header: 'Version', },
        { field: 'status', header: 'Status', },
        // { field: 'Dialog', header: 'Dialog', },
    ];

    const verifiedBodyTemplate = (rowData) => {
        let setImage = successPic;
        if (rowData?.status === 'New')
            setImage = errorPic
        else if (rowData?.status === 'In Review')
            setImage = inReviewPic
        return <img src={setImage} width="25px" alt='' />;
    };

    const verifiedVersion = (rowData) => {
        if (rowData?.status === 'New')
            return <span style={{ 'textDecoration': 'underline blue', 'cursor': 'pointer' }}
                onClick={() => onClick('displayPosition', 'bottom', rowData)}>Update</span>;
        // <Button label="Update" onClick={() => onClick('displayPosition', 'bottom', rowData)} link />;
        return rowData.version
    };

    const columns2 = [
        { field: 'category', header: 'Category', },
        { field: 'manufacturer', header: 'Manufacturer', },
        { field: 'brand', header: 'Brand', },
        { field: 'sub_brand', header: 'Sub Brand', },
        { field: 'suggested_group_name', header: 'Group Name', },
        { field: 'suggested_sub_brand_name', header: 'Sub Brand Name', },
    ]

    const dynamicColumns0 = columns0.map((col, i) => {
        if (col.field === 'id')
            return <Column field="id" header="Id" style={{ display: 'none', ...borderStyle }} ></Column>
        if (col.field === 'verified')
            return <Column field="verified" header="" dataType="boolean" bodyClassName="text-center"
                style={{ minWidth: '1rem', ...borderStyle }} />
        return <Column key={col.field} field={col.field} header={col.header} sortable style={borderStyle} />;
    });

    // const statusEditor = (options) => {
    //     return (
    //         <Dropdown
    //             value={options.value}
    //             options={statuses}
    //             onChange={(e) => options.editorCallback(e.value)}
    //             placeholder="Select a Status"
    //             itemTemplate={(option) => {
    //                 return <label>{option}</label>;
    //             }}
    //         />
    //     );
    // };

    // const statusBodyTemplate = (rowData) => {
    //     return <label>{rowData.status}</label>;
    // };

    // const onRowEditComplete = (e) => {
    //     let _products = [...products1];
    //     let { newData, index } = e;
    //     _products[index] = newData;
    //     setProducts1(_products);
    // };

    // const cellEditor = (options) => {
    //     if (options.value !== 'Approved')
    //         return textEditor(options);
    //     else
    //         return <label>{options.value}</label>;
    // };

    // const textEditor = (options) => {
    //     return <Dropdown value={options.value} options={statuses} onChange={(e) => options.editorCallback(e.value)}
    //         placeholder="Select a Status" itemTemplate={(option) => {
    //             console.log('option', option)
    //             return <label>{option}</label>;
    //         }}
    //     />
    // };

    // const onCellEditComplete = (e) => {
    //     let { rowData, newValue, field, originalEvent: event } = e;
    //     // console.log('index', rowData, newValue)
    //     switch (field) {
    //         case 'status':
    //             // console.log('field', field)
    //             const getAllProducts = products1;
    //             let _product = getAllProducts.find(val => val.id === rowData.id);
    //             _product.status = newValue;
    //             console.log('_product', _product)
    //             setProducts1(getAllProducts)
    //             rowData[field] = newValue
    //             toast.current.show({ severity: 'success', summary: 'Successful', detail: 'Product Status Updated', life: 3000 });
    //             break;
    //         // case 'price':
    //         //     if (isPositiveInteger(newValue)) rowData[field] = newValue;
    //         //     else event.preventDefault();
    //         //     break;
    //         default:
    //             if (newValue.trim().length > 0) rowData[field] = newValue;
    //             else event.preventDefault();
    //             break;
    //     }
    // };

    const dynamicColumns = columns.map((col, i) => {
        if (col.field === 'id')
            return <Column field="id" header="Id" style={{ display: 'none', ...borderStyle }}></Column>
        if (col.field === 'verified')
            return <Column field="verified" header="" dataType="boolean" bodyClassName="text-center"
                style={{ minWidth: '1rem', ...borderStyle }} body={verifiedBodyTemplate} />
        if (col.field === 'version')
            return <Column field={col.field} header={col.header} body={verifiedVersion} style={borderStyle} />
        if (col.field === 'status')
            return <Column field={col.field} header={col.header} style={{ minWidth: '10rem', ...borderStyle }}
            ></Column>
        // return <Column field={col.field} header={col.header} style={{ minWidth: '10rem', ...borderStyle }}
        // editor={(options) => cellEditor(options)} onCellEditComplete={onCellEditComplete}></Column>
        // if (col.field === 'Dialog')
        //     return <Column headerStyle={{ width: '10%', minWidth: '8rem' }} bodyStyle={{ textAlign: 'center' }}
        //         editor={(options) => cellEditor(options)} onCellEditComplete={onCellEditComplete} />
        // return <Column rowEditor headerStyle={{ width: '10%', minWidth: '8rem' }} bodyStyle={{ textAlign: 'center' }}></Column>
        return <Column key={col.field} field={col.field} header={col.header} style={{ minWidth: '5rem', ...borderStyle }} sortable />;
    });

    const dynamicColumns2 = columns2.map((col, i) => {
        if (col.field === 'suggested_group_name' || col.field === 'suggested_sub_brand_name') {
            return <Column key={col.field} field={col.field} header={col.header} style={{ 'backgroundColor': 'gray', ...borderStyle }} />;
        }
        return <Column key={col.field} field={col.field} header={col.header} style={borderStyle} />;
    });

    const handleChange = (event) => {
        if (event.target.value === '1') {
            setNameVisible('Fetching The Data Source')
            setVisible(true)
            setProducts0(JsonData)
        } else {
            toast.current.show({ severity: 'success', summary: 'Successful', detail: 'No Data Found Selected Source', life: 3000 });
            setProducts0([])
        }
        setProducts1([])
        setDataSource(event.value);
        // setVisible(false)
    };

    return (
        <div >
            {visible === true ?
                <div className="card flex justify-content-center">
                    <Dialog header={nameVisible} visible={visible} onHide={() => setVisible(false)}
                        style={{ width: '30vw' }} breakpoints={{ '960px': '75vw', '641px': '100vw' }}>
                        <CustomDemo />
                    </Dialog>
                </div> : ''}
            <Toast ref={toast} />
            <Row>
                <Col lg="9">
                    <h4>Master Data Managment</h4>
                </Col>
                <Col lg="3" >
                    <span className="p-float-label">
                        <Dropdown value={dataSource} onChange={handleChange} options={groupedCities} optionLabel="label"
                            optionGroupLabel="label" optionGroupChildren="items" optionGroupTemplate={groupedItemTemplate}
                            className="w-full md:w-18rem" style={{ 'paddingLeft': '0' }} />
                        <label htmlFor="dd-city">Data Source</label>
                    </span>
                </Col>
            </Row>
            <br />
            <div>
                {products0?.length > 0 ?
                    <div style={tableStyle}>
                        <br />
                        <Row >
                            <Col lg="9">
                                <h6>&nbsp;&nbsp; Sell In Data (SAP/ERP)</h6>
                            </Col>
                            <Col lg="3">
                                <Button style={{ 'borderRadius': '8px', 'float': 'left' }} onClick={() => callVerifyMapping()}>
                                    Verify Mapping</Button>
                            </Col>
                        </Row>
                        <br />
                        <DataTable value={products0} showGridlines tableStyle={{ minWidth: '50rem' }}
                            // style={{ "border":'1px solid' }}
                            paginator rows={5} rowsPerPageOptions={[5, 10, 25, 50]}
                            paginatorTemplate="RowsPerPageDropdown FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink CurrentPageReport"
                            currentPageReportTemplate="Showing {first} to {last} of {totalRecords} products"
                            scrollable scrollHeight="350px"// scrollDirection="both"
                            sortMode="multiple"
                            filterDisplay="menu"
                            dataKey="id"
                        >
                            {dynamicColumns0}
                        </DataTable>
                    </div>
                    :
                    <div />
                }
                {products1?.length > 0 ?
                    <div style={tableStyle}>
                        <br />
                        <Row >
                            <Col lg="9">
                                <h6>&nbsp;&nbsp; Sell In Data (SAP/ERP)</h6>
                            </Col>
                            <Col lg="3">
                                <h6 style={{ 'float': 'right' }}>Click on Update to see Suggestions.</h6>
                            </Col>
                        </Row>
                        <br />
                        <DataTable value={products1} showGridlines tableStyle={{ minWidth: '50rem' }}
                            paginator rows={5} rowsPerPageOptions={[5, 10, 25, 50]}
                            paginatorTemplate="RowsPerPageDropdown FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink CurrentPageReport"
                            currentPageReportTemplate="Showing {first} to {last} of {totalRecords} products"
                            scrollable scrollHeight="350px" // scrollDirection="both"
                            sortMode="multiple"
                            filterDisplay="menu"
                            dataKey="id"
                            editMode="cell"
                        // editMode="row" onRowEditComplete={onRowEditComplete}
                        >
                            {dynamicColumns}
                        </DataTable>
                    </div>
                    :
                    <Row />}
            </div>
            <Dialog header={'Record No:' + headerValue} visible={displayPosition} position={position} modal style={{ width: '100vw' }}
                footer={renderFooter('displayPosition')} onHide={() => onHide('displayPosition')}
                draggable={false} resizable={false}>
                <DataTable value={products2} dataKey="id">
                    {dynamicColumns2}
                </DataTable>
            </Dialog>

            <Dialog header="Modify Product" visible={visibleRight} position={position} modal
                style={{ height: '100vw', }}
                footer={renderFooter2('visibleRight')} onHide={() => onHide('visibleRight')}
                draggable={false} resizable={false}
            // className="p-fluid "
            >
                <br />
                <div className="card flex flex-column align-items-left gap-1 " style={{ 'marginBottom': 'auto' }}>
                    <span className="p-float-label">
                        <InputText id="Category" value={getCategory} onChange={e => setCategory(e.target.value)}
                            placeholder="Normal" />
                        <label htmlFor="Category">Category</label>
                    </span>
                    <br />
                    <span className="p-float-label">
                        <InputText id="Manufacturer" value={getManufacturer} onChange={e => setManufacturer(e.target.value)} />
                        <label htmlFor="Manufacturer">Manufacturer</label>
                    </span>
                    <br />
                    <span className="p-float-label">
                        <InputText id="Brand" value={getBrand} onChange={e => setBrand(e.target.value)} />
                        <label htmlFor="Brand">Brand</label>
                    </span>
                    <br />
                    <span className="p-float-label">
                        <InputText id="Sub_Brand" value={getSubBrand} onChange={e => setSubbrand(e.target.value)} />
                        <label htmlFor="Sub_Brand">Sub Brand</label>
                    </span>
                    <br />
                    <span className="p-float-label">
                        <InputText id="Group_Name" value={getGroupName} onChange={e => setGroupName(e.target.value)} />
                        <label htmlFor="Group_Name">Group Name</label>
                    </span>
                    <br />
                    <span className="p-float-label">
                        <InputText id="Sub_Brand_Name" value={getSubBrandName} onChange={e => setSubBrandName(e.target.value)} />
                        <label htmlFor="Sub_Brand_Name">Sub Brand Name</label>
                    </span>
                </div>
            </Dialog>

        </div>
    );
}

export default VerifyMapping;