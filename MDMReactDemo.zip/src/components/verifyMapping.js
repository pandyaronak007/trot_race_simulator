import React, { useState, useRef, useEffect } from 'react';
// import JsonData from '../services/salesSellOut.json';
import JsonData from '../services/edwData.json';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Button } from 'primereact/button';
import { Dialog } from 'primereact/dialog';
import { Dropdown } from 'primereact/dropdown';
import { TabView, TabPanel } from 'primereact/tabview';
import { Col, Row } from "reactstrap";
import { Toast } from 'primereact/toast';
import { ProgressSpinner } from 'primereact/progressspinner';
import api from '../services/api';

const VerifyMapping = () => {
    const [products0, setProducts0] = useState([]);
    const [products1, setProducts1] = useState([]);
    const [dataSource, setDataSource] = useState('');
    const toast = useRef(null);
    const [visible, setVisible] = useState(false);
    const [nameVisible, setNameVisible] = useState('Running Data Quality Checks');

    // updated column for the products
    const [getBrand, setBrand] = useState([]);
    const [getSubBrand, setSubBrand] = useState([]);
    const [getCategory, setCategory] = useState([]);
    const [getSubCategory, setSubCategory] = useState([]);
    const [getSegment, setSegment] = useState([]);
    const [getSubSegment, setSubSegment] = useState([]);
    const [getCountry, setCountry] = useState([]);
    const [getFact, setFact] = useState([]);

    useEffect(() => {
        if (visible) {
            setTimeout(() => {
                setNameVisible('Running Data Quality Checks');
                setVisible(false);
            }, 1000);
        }
    }, [visible]);

    const tableStyle = { 'backgroundColor': 'white', 'paddingLeft': '30px', 'paddingRight': '30px', 'paddingBottom': '30px' };
    const borderStyle = { "border": '1px solid' };

    const groupedCities = [
        {
            label: 'Sales',
            items: [
                { label: 'Sell In Data (EDW)', value: '1' }
            ]
        }
    ];

    const groupedItemTemplate = (option) => {
        return (
            <div className="flex align-items-left">
                <div>{option.label}</div>
            </div>
        );
    };

    const callApi = (url) => {
        console.log('url', url)
        api.getData(url)
            .then((response) => {
                console.log('url 2', url)
                const { data: responseData } = response
                if (url === '/verifyMapping') {
                    const { data: { tableData = [], countData = {} } } = responseData
                    if (tableData?.length > 0) {
                        setProducts1(tableData)
                    }
                } else if (url === '/loadDqPassData') {
                    const { data: {
                        categoryData = [], subCategoryData = [], brandData = [], subBrandData = [],
                        segmentData = [], subSegmentData = [], countryData = [], factData = [],
                    } } = responseData
                    setCategory(categoryData)
                    setSubCategory(subCategoryData)
                    setBrand(brandData)
                    setSubBrand(subBrandData)
                    setSegment(segmentData)
                    setSubSegment(subSegmentData)
                    setCountry(countryData)
                    setFact(factData)
                    setProducts1([])
                }
                setProducts0([])
            })
            .catch((error) => {
                console.log('error ===>', error)
            })
    }

    const callLoadDqPassData = () => {
        setVisible(true)
        callApi('/loadDqPassData');
    }

    const callVerifyMapping = () => {
        setVisible(true)
        callApi('/verifyMapping');
    }

    const CustomDemo = () => {
        return (
            <div className="card">
                <ProgressSpinner />
            </div>
        );
    }


    const columns0 = [
        { field: 'ITEM_ID', header: 'Item Id' },
        { field: 'MARKET', header: 'Market' },
        { field: 'BRAND', header: 'Brand' },
        { field: 'SUB_BRAND', header: 'Sub Brand' },
        { field: 'SEGMENT', header: 'Segment' },
        { field: 'SUB_SEGMENT', header: 'Sub Segment' },
        { field: 'SUM_SLS_VOL', header: 'Sum Sls Vol' },
        { field: 'SUM_SLS_VAL_LCLCCY_AMT', header: 'Sum Sls Vol Lclccy Amt' },
    ];

    const columns = [
        { field: 'ITEM_ID', header: 'Item Id' },
        { field: 'MARKET', header: 'Market' },
        { field: 'BRAND', header: 'Brand' },
        { field: 'SUB_BRAND', header: 'Sub Brand' },
        { field: 'SEGMENT', header: 'Segment' },
        { field: 'SUB_SEGMENT', header: 'Sub Segment' },
        { field: 'SUM_SLS_VOL', header: 'Sum Sls Vol' },
        { field: 'SUM_SLS_VAL_LCLCCY_AMT', header: 'Sum Sls Vol Lclccy Amt' },
        { field: 'rule_name', header: 'Rule Name' },
        { field: 'rule_result', header: 'Rule Result' },
    ];

    const columns2 = [
        { field: 'category', header: 'Category', },
        { field: 'manufacturer', header: 'Manufacturer', },
        { field: 'brand', header: 'Brand', },
        { field: 'sub_brand', header: 'Sub Brand', },
        { field: 'suggested_group_name', header: 'Group Name', },
        { field: 'suggested_sub_brand_name', header: 'Sub Brand Name', },
    ]

    const dynamicColumns0 = columns0.map((col, i) => {
        return <Column key={col.field} field={col.field} header={col.header} sortable style={borderStyle} />;
    });


    const dynamicColumns = columns.map((col, i) => {
        return <Column key={col.field} field={col.field} header={col.header} style={{ minWidth: '100px', ...borderStyle }} sortable />;
    });

    const handleChange = (event) => {
        if (event.target.value === '1') {
            setNameVisible('Fetching The Data Source')
            setVisible(true)
            setProducts0(JsonData)
        } else {
            toast.current.show({ severity: 'success', summary: 'Successful', detail: 'No Data Found Selected Source', life: 3000 });
            setProducts0([])
        }
        setProducts1([])
        setDataSource(event.value);
    };

    return (
        <div >
            {visible === true ?
                <div className="card flex justify-content-center">
                    <Dialog header={nameVisible} visible={visible} onHide={() => setVisible(false)}
                        style={{ width: '30vw' }} breakpoints={{ '960px': '75vw', '641px': '100vw' }}>
                        <CustomDemo />
                    </Dialog>
                </div> : ''}
            <Toast ref={toast} />
            <Row>
                <Col lg="9">
                    <h4>Master Data Managment</h4>
                </Col>
                <Col lg="3" >
                    <span className="p-float-label">
                        <Dropdown value={dataSource} onChange={handleChange} options={groupedCities} optionLabel="label"
                            optionGroupLabel="label" optionGroupChildren="items" optionGroupTemplate={groupedItemTemplate}
                            className="w-full md:w-18rem" style={{ 'paddingLeft': '0' }} />
                        <label htmlFor="dd-city">Data Source</label>
                    </span>
                </Col>
            </Row>
            <br />
            <div>
                {products0?.length > 0 ?
                    <div style={tableStyle}>
                        <br />
                        <Row >
                            <Col lg="9">
                                <h6>&nbsp;&nbsp; Sell In Data (EDW)</h6>
                            </Col>
                            <Col lg="3">
                                <Button style={{ 'borderRadius': '8px', 'float': 'left' }} onClick={() => callVerifyMapping()}>
                                    Verify Mapping</Button>
                            </Col>
                        </Row>
                        <br />
                        <DataTable value={products0} showGridlines tableStyle={{ minWidth: '50rem' }}
                            // style={{ "border":'1px solid' }}
                            paginator rows={5} rowsPerPageOptions={[5, 10, 25, 50]}
                            paginatorTemplate="RowsPerPageDropdown FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink CurrentPageReport"
                            currentPageReportTemplate="Showing {first} to {last} of {totalRecords} products"
                            scrollable scrollHeight="350px"// scrollDirection="both"
                            sortMode="multiple"
                            filterDisplay="menu"
                        // dataKey="id"
                        >
                            {dynamicColumns0}
                        </DataTable>
                    </div>
                    :
                    <div />
                }
                {products1?.length > 0 ?
                    <div style={tableStyle}>
                        <br />
                        <Row >
                            <Col lg="9">
                                <h6>&nbsp;&nbsp; Sell In Data (EDW)</h6>
                            </Col>
                            <Col lg="3">
                                <Button style={{ 'borderRadius': '8px', 'float': 'left' }} onClick={() => callLoadDqPassData()}>
                                    Load Dq Pass Data</Button>
                            </Col>
                        </Row>
                        <br />
                        <DataTable value={products1} showGridlines tableStyle={{ minWidth: '50rem' }}
                            paginator rows={5} rowsPerPageOptions={[5, 10, 25, 50]}
                            paginatorTemplate="RowsPerPageDropdown FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink CurrentPageReport"
                            currentPageReportTemplate="Showing {first} to {last} of {totalRecords} products"
                            scrollable scrollHeight="350px"
                        // sortMode="multiple"
                        // filterDisplay="menu"
                        // dataKey="id"
                        // editMode="cell"
                        // editMode="row" onRowEditComplete={onRowEditComplete}
                        >
                            {dynamicColumns}
                        </DataTable>
                    </div>
                    :
                    <div />}
                {getCategory?.length > 0 ?
                    <div className="card" style={tableStyle}>
                        <TabView>
                            <TabPanel header="Fact">
                                <DataTable value={getFact} showGridlines tableStyle={{ minWidth: '50rem' }}>
                                    <Column field="fact_id" header="Fact Id" style={borderStyle} />
                                    <Column field="ITEM_ID" header="Item Id" style={borderStyle} />
                                    <Column field="SUM_STOR_CNT" header="Sum Stor Cnt" style={borderStyle} />
                                    <Column field="SUM_SLS_UNITS" header="Sum Sls Unites" style={borderStyle} />
                                    <Column field="SUM_SLS_VAL_LCLCCY_AMT" header="Sum Sls Val Lalccy Amt" style={borderStyle} />
                                </DataTable>
                            </TabPanel>
                            <TabPanel header="Country">
                                <DataTable value={getCountry} showGridlines tableStyle={{ minWidth: '50rem' }}>
                                    <Column field="cntry_id" header="Country Id" style={borderStyle} />
                                    <Column field="cntry" header="Country" style={borderStyle} />
                                </DataTable>
                            </TabPanel>
                            <TabPanel header="Brand">
                                <DataTable value={getBrand} showGridlines tableStyle={{ minWidth: '50rem' }}>
                                    <Column field="brand_id" header="Brand Id" style={borderStyle} />
                                    <Column field="brand" header="Brand" style={borderStyle} />
                                </DataTable>
                            </TabPanel>
                            <TabPanel header="Sub Brand">
                                <DataTable value={getSubBrand} showGridlines tableStyle={{ minWidth: '50rem' }}>
                                    <Column field="sub_brand_id" header="Sub Brand Id" style={borderStyle} />
                                    <Column field="sub_brand" header="Sub Brand" style={borderStyle} />
                                    <Column field="brand_id" header="Brand Id" style={borderStyle} />
                                    <Column field="brand_code" header="Brand Code" style={borderStyle} />
                                </DataTable>
                            </TabPanel>
                            <TabPanel header="Category" >
                                <DataTable value={getCategory} showGridlines tableStyle={{ minWidth: '50rem' }}>
                                    <Column field="cat_id" header="Category Id" style={borderStyle} />
                                    <Column field="category" header="Category" style={borderStyle} />
                                </DataTable>
                            </TabPanel>
                            <TabPanel header="Sub Category">
                                <DataTable value={getSubCategory} showGridlines tableStyle={{ minWidth: '50rem' }}>
                                    <Column field="sub_category" header="Sub Category" style={borderStyle} />
                                    <Column field="category" header="Category" style={borderStyle} />
                                </DataTable>
                            </TabPanel>
                            <TabPanel header="Segment">
                                <DataTable value={getSegment} showGridlines tableStyle={{ minWidth: '50rem' }}>
                                    <Column field="seg_id" header="Segment Id" style={borderStyle} />
                                    <Column field="segment" header="Segment" style={borderStyle} />
                                </DataTable>
                            </TabPanel>
                            <TabPanel header="Sub Segment">
                                <DataTable value={getSubSegment} showGridlines tableStyle={{ minWidth: '50rem' }}>
                                    <Column field="sub_seg_id" header="Sub Segment Id" style={borderStyle} />
                                    <Column field="sub_segment" header="Sub Segment" style={borderStyle} />
                                    <Column field="seg_id" header="Segment Id" style={borderStyle} />
                                </DataTable>
                            </TabPanel>
                        </TabView>
                    </div>
                    : <div />}
            </div>
        </div>
    );
}

export default VerifyMapping;