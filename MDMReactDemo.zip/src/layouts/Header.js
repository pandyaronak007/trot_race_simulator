import React from "react";
// import { Link } from "react-router-dom";
import { Navbar, Collapse, Nav, NavItem, } from "reactstrap";
import profilePic from "../assets/images/users/Profile.svg";
import menuPic from "../assets/images/users/Menu.svg";
import logoPic from "../assets/images/users/TSC_Logo_Black.svg";

const Header = () => {

  return (
    <div>
      <Navbar color="primary" dark expand="md">
        <Collapse navbar>
          <img src={menuPic} alt="profile" className="rounded-circle" width="30" />
          <img src={logoPic} alt="profile" style={{ 'paddingLeft': '1%' }} />
          <Nav className="me-auto" navbar>
            <NavItem>
              {/* <Link to="/Starter" className="nav-link">
              Starter
            </Link> */}
            </NavItem>
          </Nav>
          <img src={profilePic} alt="profile" className="rounded-circle" width="30" />
        </Collapse>
      </Navbar>
    </div>
  );
};

export default Header;
