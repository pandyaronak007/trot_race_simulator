const express = require("express");
const app = express();
const path = require('path');
const cors = require('cors');
const { spawnSync, spawn } = require('child_process');

const data = require('./data/users.json')
const getErrorData = require('./data/setFile/input_error.json');
const getDuplicateData = require('./data/setFile/input_dup.json');
const getWarningData = require('./data/setFile/input_war.json');
const getDqData = require('./data/setFile/input_dq_summ.json');


// const firstScript = "script/generateSummary.py";
// const secondScript = "script/MDMFinalSummary.py";

app.use(cors())

// const middleware = require("../src/routes");
// app.use("/cat", middleware);

app.get("/verifyMapping", async (req, res) => {
    try {
        const pythonProcess = await spawnSync('python', ['-W ignore ', path.join(__dirname, 'script/generateSummary.py')]);
        const result = pythonProcess.stdout?.toString()?.trim();
        const error = pythonProcess.stderr?.toString()?.trim();
        const concateData = [];

        if (result.includes('DQ Summary Report Generated') && !error)
            res.send({
                status: 200, message: 'DQ Summary Report Generated',
                data: {
                    tableData:
                        concateData.concat(
                            getErrorData.length > 0 ? getErrorData : [],
                            getDuplicateData.length > 0 ? getDuplicateData : [],
                            getWarningData.length > 0 ? getWarningData : []
                        ),
                    countData: getDqData?.Overview || {}
                }
            });
        else
            res.send({ status: 400, message: error });
    } catch (err) {
        res.send({ status: 400, message: err });
    }
});

app.get("/loadDqPassData", async (req, res) => {
    try {
        const pythonProcess = await spawnSync('python', ['-W ignore ', path.join(__dirname, 'script/MDMFinalSummary.py')]);
        const result = pythonProcess.stdout?.toString()?.trim();
        const error = pythonProcess.stderr?.toString()?.trim();
        const concateData = [];

        const brandMasterData = require('./data/masterFile/brandMaster.json');
        const subBrandMasterData = require('./data/masterFile/subBrandMaster.json');
        const categoryMasterData = require('./data/masterFile/categoryMaster.json');
        const subCategoryMasterData = require('./data/masterFile/subCategoryMaster.json');
        const segmentMasterData = require('./data/masterFile/segmentMaster.json');
        const subSegmentMasterData = require('./data/masterFile/subSegmentMaster.json');
        const countryMasterData = require('./data/masterFile/countryMaster.json');
        const factMasterData = require('./data/masterFile/factMaster.json');

        if (result.includes('Process has completed') && !error)
            res.send({
                status: 200, message: 'Process has completed',
                data: {
                    brandData: brandMasterData.length > 0 ? brandMasterData.slice(0, 5) : [],
                    subBrandData: subBrandMasterData.length > 0 ? subBrandMasterData.slice(0, 5) : [],
                    categoryData: categoryMasterData.length > 0 ? categoryMasterData.slice(0, 5) : [],
                    subCategoryData: subCategoryMasterData.length > 0 ? subCategoryMasterData.slice(0, 5) : [],
                    segmentData: segmentMasterData.length > 0 ? segmentMasterData.slice(0, 5) : [],
                    subSegmentData: subSegmentMasterData.length > 0 ? subSegmentMasterData.slice(0, 5) : [],
                    countryData: countryMasterData.length > 0 ? countryMasterData.slice(0, 5) : [],
                    factData: factMasterData.length > 0 ? factMasterData.slice(0, 5) : [],
                }
            });
        else
            res.send({ status: 400, message: error });
    } catch (err) {
        res.send({ status: 400, message: err });
    }
});

module.exports = app;