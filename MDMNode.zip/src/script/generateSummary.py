# Databricks notebook source
import pandas as pd
import subprocess
from datetime import datetime

# COMMAND ----------
# DBTITLE 1,Schema Check Defined
def perform_schema_check(df, expected_columns):
    # Checking the DataFrame has the expected columns
    missing_columns = set(expected_columns) - set(df.columns)
    new_line ='\n'

    if missing_columns:
        return f"Missing columns: {', '.join(missing_columns)}"

    # Checking if the column names match
    if set(expected_columns) != set(df.columns): 
        return f"""COLUMN NAMES DO NOT MATCH. <br> EXPECTED COLUMN NAMES ARE : {', '.join(expected_columns)} 
        <br>
        <br>
        THE ACTUAL NAMES WE HAVE ARE : {', '.join(df.columns)}"""

    return None

# COMMAND ----------
# DBTITLE 1,Data Quality Rules Defined

def region_null(row):
  if row["MARKET"] is None:
      return "error"
  else:
      return "no issue"

def brand_null(row):
  if row["BRAND"] is None:
      return "error"
  else:
      return "no issue"

def sub_brand_null(row):
    if row["SUB_BRAND"] is None:
        return "error"
    else:
        return "no issue"

def category_null(row):
    if row["CATEGORY"] is None:
        return "error"
    else:
        return "no issue"

def Item_id_null(row):
    if row["ITEM_ID"] is None:
        return "error"
    else:
        return "no issue"

def week_null(row):
    if row["WEEK"] is None:
        return "error"
    else:
        return "no issue"

def value_sales_is_null(row):
    if pd.isna(row["SUM_SLS_VAL_LCLCCY_AMT"]):
        return "error"
    else:
        return "no issue"
    
def volume_sales_is_null(row):
    if pd.isna(row["SUM_SLS_VOL"]):
        return "error"
    else:
        return "no issue"

# COMMAND ----------

# DBTITLE 1,Duplicate Check Defined
def identify_duplicates(dataframe):
    result_data = []

    unique_rows = {}

    for index, row in dataframe.iterrows():
        row_tuple = tuple([val if pd.notna(val) else 'nan' for val in row])
        
        if row_tuple in unique_rows:
            unique_rows[row_tuple].append(index)
        else:
            unique_rows[row_tuple] = [index]
    

    for row_tuple, indices in unique_rows.items():
        if len(indices) > 1:
            result_data.append(([index + 2 for index in indices ], 'duplicate'))
        else:
            result_data.append((indices, 'unique'))

    result_df = pd.DataFrame(result_data, columns=['duplicate_indices', 'rule_result'])
    result_df['rule_name'] = 'duplicate'
    result_df['duplicate_indices'] = result_df['duplicate_indices'].apply(lambda indices: '|'.join(map(str, indices)))
    result_df = pd.concat([dataframe, result_df], axis=1)
    return result_df

# COMMAND ----------
# DBTITLE 1,Main Method
def main():
  # path = r"/Workspace/Users/u419479@wns.com/Input/"
  getPath = r"D:/Project/TCS project/Node/src/data/getFile/"
  setPath = r"D:/Project/TCS project/Node/src/data/setFile/"
  raw_df = pd.read_excel(getPath+"poc_data_raw.xlsx")
  print("\n Dataframe Read Completed")
  print("\n Initiating Schema Check")
  expected_columns = ['SOURCE','CHANNEL','GRANULARITY','HIERARCHY','WEEK','MARKET','GEO_LEVEL','GEO_UNIT','BRAND','SUB_BRAND','MANUFACTURER','CATEGORY','SUB_CATEGORY','SEGMENT','SUB_SEGMENT','ITEM_ID','MULTIPACK_QTY_VAL','PACKAGE_TYPE','SERVING_TYPE','DSTRBTN_CHCKOUT_NUMRC','DSTRBTN_CHCKOUT_WGHTD','DSTRBTN_CHLLD_WGHTD','DSTRBTN_NUMRC',
  'DSTRBTN_OOS_NUMRC','DSTRBTN_OOS_WGHTD','DSTRBTN_WGHTD','DSTRBTN_WGHTD_ANY_PROMO','DSTRBTN_WGHTD_DSPLY','DSTRBTN_WTD_FEATR','DSTRBTN_WGHTD_FEATR_AND_DSPLY','SUM_STOR_CNT','SUM_SLS_UNITS','SUM_SLS_VAL_LCLCCY_AMT','SUM_SLS_VOL', 'SUM_TOT_DSTRBTN_PTS','DISTR_WTD_VOL']
  var_out = perform_schema_check(raw_df, expected_columns)
  if var_out == None:
    print("\n Schema checks have passed")
  else:
    print("\n Schema checked have failed")
    print("\n"+var_out)
  print("\n Define the Data Quality Rules")
  data_quality_rules = {"region_null" : region_null, "brand_null" : brand_null, "sub_brand_null" : sub_brand_null, "category_null" : category_null,"Item_id_null":Item_id_null,"week_null": week_null,"value_sales_is_null": value_sales_is_null, "volume_sales_is_null": volume_sales_is_null}
  print("\n Setting up the row id's")
  raw_df = raw_df.reset_index(drop=True)
  raw_df['RID'] = raw_df.index+1
  column_name = ['DSTRBTN_CHCKOUT_NUMRC','DSTRBTN_CHCKOUT_WGHTD','DSTRBTN_CHLLD_WGHTD','DSTRBTN_NUMRC','DSTRBTN_OOS_NUMRC','DSTRBTN_OOS_WGHTD','DSTRBTN_WGHTD','DSTRBTN_WGHTD_ANY_PROMO','DSTRBTN_WGHTD_DSPLY','DSTRBTN_WTD_FEATR','DSTRBTN_WGHTD_FEATR_AND_DSPLY','SUM_STOR_CNT','SUM_SLS_UNITS','SUM_SLS_VAL_LCLCCY_AMT','SUM_SLS_VOL','SUM_TOT_DSTRBTN_PTS','DISTR_WTD_VOL']
  raw_df[column_name] = raw_df[column_name].apply(pd.to_numeric, errors='coerce', axis=1)
  date_columns = ['WEEK']
  print("\n Running the Data Quality Rules")
  for col in date_columns:
    raw_df[col] = pd.to_datetime(raw_df[col]).dt.date
  result_df_pre = raw_df.copy()
  # result_df_pre=pd.DataFrame()
  for rule_name, function in data_quality_rules.items():
    result_df_pre[rule_name] = raw_df.apply(function, axis=1)
  
  result_df = result_df_pre.melt(id_vars=raw_df.columns, var_name="rule_name", value_name="rule_result")
  print("\n Data Quality Rules Execution Completed")

# Dividing the results in to three parts based on the rule  results 
  expected_columns_final = expected_columns + ['rule_name','rule_result']
  warning_df = result_df[result_df['rule_result'] == 'warning']
  warning_df_final = warning_df[expected_columns_final]

  warning_df_final.to_json(setPath+'input_war.json', orient='records')
  print("\n Warning Data Json Created")
  no_issue_df = result_df[result_df['rule_result'] == 'no issue']
  
  no_issue_df.to_json(setPath+'input_clean.json')
  print("\n No Issues Data Json Created")
  no_issue_df.to_excel(setPath+'input_clean.xlsx')
  
  error_df = result_df[result_df['rule_result'] == 'error']
  error_df_final= error_df[expected_columns_final]
  error_df_final.to_json(setPath+'input_error.json', orient='records')
  print("\n Errors Data Json Created")
  column_to_drop = 'RID'
  pandas_df_new = raw_df.drop(column_to_drop,axis = 1)
  pandas_df_new = pandas_df_new.reset_index(drop=True)
  duplicate_df = identify_duplicates(pandas_df_new)
  duplicate_df = duplicate_df[duplicate_df['rule_result'] == 'duplicate']
  duplicate_df_final = duplicate_df[expected_columns_final]
  duplicate_df_final.to_json(setPath+'input_dup.json', orient='records')
  print("\n Duplicate Data Check Completed and Json Generated")
  nbr_rows_in_media = len(raw_df)
  nbr_rows_with_error = len(error_df_final)
  nbr_rows_with_warning = len(warning_df_final)
  nbr_rows_with_duplicate = len(duplicate_df_final)
  overview_dict = {}
  overview_dict['total_rows'] = [nbr_rows_in_media]
  overview_dict['total_failed_dq_check'] = [nbr_rows_with_error]
  overview_dict['total_warning_dq_check'] = [nbr_rows_with_warning]
  overview_dict['total_duplicate_dq_check'] = [nbr_rows_with_duplicate]
  overview_df = pd.DataFrame.from_dict(overview_dict).T
  overview_df.columns = ['Overview']
  overview_df.to_json(setPath+'input_dq_summ.json')
  print("\n DQ Summary Report Generated")

if __name__==main():
  main()
