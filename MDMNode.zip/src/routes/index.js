const express = require("express");
const router = express.Router();
const fact = require("./callScript");

router.get("/facts", fact);

module.exports = router;